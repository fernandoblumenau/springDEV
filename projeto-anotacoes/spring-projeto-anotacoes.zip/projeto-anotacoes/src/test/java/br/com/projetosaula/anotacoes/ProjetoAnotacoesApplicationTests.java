package br.com.projetosaula.anotacoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAnotacoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
