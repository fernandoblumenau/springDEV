package br.com.projetosaula.anotacoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoAnotacoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoAnotacoesApplication.class, args);
	}

}
